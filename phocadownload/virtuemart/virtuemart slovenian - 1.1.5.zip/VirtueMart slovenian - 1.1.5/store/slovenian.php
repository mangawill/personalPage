<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_USER_FORM_FIRST_NAME' => 'Ime',
	'PHPSHOP_USER_FORM_LAST_NAME' => 'Priimek',
	'PHPSHOP_USER_FORM_MIDDLE_NAME' => 'Srednje Ime',
	'PHPSHOP_USER_FORM_COMPANY_NAME' => 'Ime Podjetja',
	'PHPSHOP_USER_FORM_ADDRESS_1' => 'Naslov 1',
	'PHPSHOP_USER_FORM_ADDRESS_2' => 'Naslov 2',
	'PHPSHOP_USER_FORM_CITY' => 'Mesto',
	'PHPSHOP_USER_FORM_STATE' => 'Občina/Provinca/Regija',
	'PHPSHOP_USER_FORM_ZIP' => 'Zip/ Poštna številka',
	'PHPSHOP_USER_FORM_COUNTRY' => 'Država',
	'PHPSHOP_USER_FORM_PHONE' => 'Telefon',
	'PHPSHOP_USER_FORM_PHONE2' => 'Mobitel',
	'PHPSHOP_USER_FORM_FAX' => 'Faks',
	'PHPSHOP_ISSHIP_LIST_PUBLISH_LBL' => 'Aktiven',
	'PHPSHOP_ISSHIP_FORM_UPDATE_LBL' => 'Nastavi Metodo Pošiljanja',
	'PHPSHOP_STORE_FORM_FULL_IMAGE' => 'Velika Slika',
	'PHPSHOP_STORE_FORM_UPLOAD' => 'Naloži Sliko',
	'PHPSHOP_STORE_FORM_STORE_NAME' => 'Ime Trgovine',
	'PHPSHOP_STORE_FORM_COMPANY_NAME' => 'Ime Podjetja Trgovine',
	'PHPSHOP_STORE_FORM_ADDRESS_1' => 'Naslov 1',
	'PHPSHOP_STORE_FORM_ADDRESS_2' => 'Naslov 2',
	'PHPSHOP_STORE_FORM_CITY' => 'Mesto',
	'PHPSHOP_STORE_FORM_STATE' => 'Občina/Provinca/Regija',
	'PHPSHOP_STORE_FORM_COUNTRY' => 'Država',
	'PHPSHOP_STORE_FORM_ZIP' => 'Zip/Poštna številka',
	'PHPSHOP_STORE_FORM_CURRENCY' => 'Valuta',
	'PHPSHOP_STORE_FORM_LAST_NAME' => 'Priimek',
	'PHPSHOP_STORE_FORM_FIRST_NAME' => 'Ime',
	'PHPSHOP_STORE_FORM_MIDDLE_NAME' => 'Srednje Ime',
	'PHPSHOP_STORE_FORM_TITLE' => 'Naslov',
	'PHPSHOP_STORE_FORM_PHONE_1' => 'Telefon 1',
	'PHPSHOP_STORE_FORM_PHONE_2' => 'Telefon 2',
	'PHPSHOP_STORE_FORM_DESCRIPTION' => 'Opis',
	'PHPSHOP_PAYMENT_METHOD_LIST_LBL' => 'Seznam Plačilnih Metod',
	'PHPSHOP_PAYMENT_METHOD_LIST_NAME' => 'Ime',
	'PHPSHOP_PAYMENT_METHOD_LIST_CODE' => 'Koda',
	'PHPSHOP_PAYMENT_METHOD_LIST_SHOPPER_GROUP' => 'Skupina Kupcev',
	'PHPSHOP_PAYMENT_METHOD_LIST_ENABLE_PROCESSOR' => 'Tip plačilne metode',
	'PHPSHOP_PAYMENT_METHOD_FORM_LBL' => 'Obrazec Plačilne Metode',
	'PHPSHOP_PAYMENT_METHOD_FORM_NAME' => 'Ime Plačilne Metode',
	'PHPSHOP_PAYMENT_METHOD_FORM_SHOPPER_GROUP' => 'Skupina Kupcev',
	'PHPSHOP_PAYMENT_METHOD_FORM_DISCOUNT' => 'Popust',
	'PHPSHOP_PAYMENT_METHOD_FORM_CODE' => 'Koda',
	'PHPSHOP_PAYMENT_METHOD_FORM_LIST_ORDER' => 'Seznam Naročil',
	'PHPSHOP_PAYMENT_METHOD_FORM_ENABLE_PROCESSOR' => 'Tip plačilne metode',
	'PHPSHOP_PAYMENT_FORM_CC' => 'Kreditna Kartica',
	'PHPSHOP_PAYMENT_FORM_USE_PP' => 'Uporabite plačilni Processor',
	'PHPSHOP_PAYMENT_FORM_BANK_DEBIT' => 'Bančni dolg',
	'PHPSHOP_PAYMENT_FORM_AO' => 'Samo Naslov / Gotovina po pozvetju',
	'PHPSHOP_STATISTIC_STATISTICS' => 'Statistika',
	'PHPSHOP_STATISTIC_CUSTOMERS' => 'Sranke',
	'PHPSHOP_STATISTIC_ACTIVE_PRODUCTS' => 'aktivni Izdelki',
	'PHPSHOP_STATISTIC_INACTIVE_PRODUCTS' => 'neaktivni Izdelki',
	'PHPSHOP_STATISTIC_NEW_ORDERS' => 'Nova Naročila',
	'PHPSHOP_STATISTIC_NEW_CUSTOMERS' => 'Nove Stranke',
	'PHPSHOP_CREDITCARD_NAME' => 'Ime Kreditne Kartice',
	'PHPSHOP_CREDITCARD_CODE' => 'Kreditna Kartica - Kratka koda',
	'PHPSHOP_YOUR_STORE' => 'Vaša Trgovina',
	'PHPSHOP_CONTROL_PANEL' => 'Nadzorna Plošča',
	'PHPSHOP_CHANGE_PASSKEY_FORM' => 'Pokaži/Spremeni Geslo/Transakcijski Ključ',
	'PHPSHOP_TYPE_PASSWORD' => 'Vtipkajte prosim vaše Uporabniško Geslo (Vaše Joomla Geslo)',
	'PHPSHOP_CURRENT_TRANSACTION_KEY' => 'Trenutni Transakcijski Ključ',
	'PHPSHOP_CHANGE_PASSKEY_SUCCESS' => 'Transakcijski ključ je bil uspešno spremenjen.',
	'VM_PAYMENT_CLASS_NAME' => 'Ime kategorije plačila',
	'VM_PAYMENT_CLASS_NAME_TIP' => '(npr. <strong>ps_netbanx</strong>) :<br />
		privzeto: ps_payment<br />
		<em>Izberi ps_payment če niste prepričani kaj izbrati!</em>',
	'VM_PAYMENT_EXTRAINFO' => 'Dodatne informacije o plačilu',
	'VM_PAYMENT_EXTRAINFO_TIP' => 'Se pokaže na strani o potrditvi naročila. Lahko je: HTML Koda Obrazca od vašega ponudnika plačila, namigi stranki,...',
	'VM_PAYMENT_ACCEPTED_CREDITCARDS' => 'Sprejeti Tipi Kreditnih Kartic',
	'VM_PAYMENT_METHOD_DISCOUNT_TIP' => 'Da vklopite popust v ceno, uporabite negativno vrednost tukaj (Primer: <strong>-2.00</strong>).',
	'VM_PAYMENT_METHOD_DISCOUNT_MAX_AMOUNT' => 'Maksimalna količina popusta',
	'VM_PAYMENT_METHOD_DISCOUNT_MIN_AMOUNT' => 'Minimalna količina popusta',
	'VM_PAYMENT_FORM_FORMBASED' => 'HTML-Oblika (npr. PayPal)',
	'VM_ORDER_EXPORT_MODULE_LIST_LBL' => 'Izvozi Seznam Modulov',
	'VM_ORDER_EXPORT_MODULE_LIST_NAME' => 'Ime',
	'VM_ORDER_EXPORT_MODULE_LIST_DESC' => 'Opis',
	'VM_STORE_FORM_ACCEPTED_CURRENCIES' => 'Seznam sprejetih valut',
	'VM_STORE_FORM_ACCEPTED_CURRENCIES_TIP' => 'Ta seznam definira vse valute, ki so podprte in v katerih se lahko nakupuje v trgovini. <strong>Obvestilo:</strong> Vse valute izbrane tukaj se lahko uporabijo ob zaključku nakupa! Če tega nočete samo izberite svojo valuto v državi.',
	'VM_EXPORT_MODULE_FORM_LBL' => 'Izvozi modul obrazca',
	'VM_EXPORT_MODULE_FORM_NAME' => 'Izvozi ime modula',
	'VM_EXPORT_MODULE_FORM_DESC' => 'Opis',
	'VM_EXPORT_CLASS_NAME' => 'Izvozi ime razreda',
	'VM_EXPORT_CLASS_NAME_TIP' => '(npr. <strong>ps_orders_csv</strong>) :<br /> privzeto: ps_xmlexport<br /> <i>Pustite prazno če ne veste kaj izpolniti!</i>',
	'VM_EXPORT_CONFIG' => 'Izvozite Dodatne Nastavitve',
	'VM_EXPORT_CONFIG_TIP' => 'Definirajte izvozne nastavitve za posamezne uporabnike ali definirajte dodatne nastavitve. Koda mora biti veljavna PHP koda.',
	'VM_SHIPPING_MODULE_LIST_NAME' => 'Ime',
	'VM_SHIPPING_MODULE_LIST_E_VERSION' => 'Različica',
	'VM_SHIPPING_MODULE_LIST_HEADER_AUTHOR' => 'Avtor',
	'PHPSHOP_STORE_ADDRESS_FORMAT' => 'Oblika naslova trgovine',
	'PHPSHOP_STORE_ADDRESS_FORMAT_TIP' => 'Lahko uporabite naslednja polja tukaj',
	'PHPSHOP_STORE_DATE_FORMAT' => 'Oblika Datuma Trgovine',
	'VM_PAYMENT_METHOD_ID_NOT_PROVIDED' => 'Napaka: Plačilna metoda ID-ja ni bila posredovana.',
	'VM_SHIPPING_MODULE_CONFIG_LBL' => 'Nastavitve Modula Pošiljanja',
	'VM_SHIPPING_MODULE_CLASSERROR' => 'Ni bilo mogoče inicializirati {shipping_module}'
); $VM_LANG->initModule( 'store', $langvars );
?>
