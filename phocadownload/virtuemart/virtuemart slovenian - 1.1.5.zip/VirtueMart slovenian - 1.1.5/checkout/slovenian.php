<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_NO_CUSTOMER' => 'Niste še registrirana stranka. Prosimo uredite vaše podatke.',
	'PHPSHOP_THANKYOU' => 'Hvala za vaše naročilo.',
	'PHPSHOP_EMAIL_SENDTO' => 'E-pošta s potrditvijo je bila poslana na',
	'PHPSHOP_CHECKOUT_NEXT' => 'Naprej',
	'PHPSHOP_CHECKOUT_CONF_BILLINFO' => 'Informacije o plačniku',
	'PHPSHOP_CHECKOUT_CONF_COMPANY' => 'Podjetje',
	'PHPSHOP_CHECKOUT_CONF_NAME' => 'Ime',
	'PHPSHOP_CHECKOUT_CONF_ADDRESS' => 'Naslov',
	'PHPSHOP_CHECKOUT_CONF_EMAIL' => 'Email',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO' => 'Informacije o prejemniku',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO_COMPANY' => 'Podjetje',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO_NAME' => 'Ime',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO_ADDRESS' => 'Naslov',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO_PHONE' => 'Telefon',
	'PHPSHOP_CHECKOUT_CONF_SHIPINFO_FAX' => 'Faks',
	'PHPSHOP_CHECKOUT_CONF_PAYINFO_METHOD' => 'Način Plačila',
	'PHPSHOP_CHECKOUT_CONF_PAYINFO_REQINFO' => 'Zahtevane informacije ko je izbran način plačila s kreditno kartico',
	'PHPSHOP_PAYPAL_THANKYOU' => 'Hvala za vaše plačilo. 
        Transakcija je bila uspešna. Prejeli boste potrditveni e-mail za transakcijo preko PayPal-a. 
        Sedaj lahko nadaljujete ali pa se prijavite na <a href=http://www.paypal.com>www.paypal.com</a>, da si ogledate podrobnosti transakcije.',
	'PHPSHOP_PAYPAL_ERROR' => 'Pri procesiranju transakcije se je pojavila napaka. Status vašega naročila ni bilo mogoče posodobiti.',
	'PHPSHOP_THANKYOU_SUCCESS' => 'Vaše naročilo je bilo uspešno sprejeto!',
	'VM_CHECKOUT_TITLE_TAG' => 'Nakup: Korak %s od %s',
	'VM_CHECKOUT_ORDERIDNOTSET' => 'Naročitve ID ni nastavljen ali pa je prazen!',
	'VM_CHECKOUT_FAILURE' => 'Napaka',
	'VM_CHECKOUT_SUCCESS' => 'Uspešno',
	'VM_CHECKOUT_PAGE_GATEWAY_EXPLAIN_1' => 'Ta stran se nahaja na spletni strani trgovine.',
	'VM_CHECKOUT_PAGE_GATEWAY_EXPLAIN_2' => 'Prehod izvrši stran na spletni strani in prikaže rezultate SSL kriptirane.',
	'VM_CHECKOUT_CCV_CODE' => 'Validacijska koda kreditne kartice',
	'VM_CHECKOUT_CCV_CODE_TIPTITLE' => 'Kakšna je validacijska koda kreditne kartice?',
	'VM_CHECKOUT_MD5_FAILED' => 'MD5 preizkus končal z napako',
	'VM_CHECKOUT_ORDERNOTFOUND' => 'Naročila ni mogoče najti',
	'PHPSHOP_EPAY_PAYMENT_CARDTYPE' => 'Plačilo je
ustvarjeno %s <img
src="/components/com_virtuemart/shop_image/ps_image/epay_images/%s"
border="0">'
); $VM_LANG->initModule( 'checkout', $langvars );
?>
