<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_BROWSE_LBL' => 'Brskaj',
	'PHPSHOP_FLYPAGE_LBL' => 'Podrobnosti Izdelka',
	'PHPSHOP_PRODUCT_FORM_EDIT_PRODUCT' => 'Uredi ta Izdelek',
	'PHPSHOP_DOWNLOADS_START' => 'Začni Prenos',
	'PHPSHOP_DOWNLOADS_INFO' => 'Prosimo vnesite ID za prenos, ki ste ga dobili preko email sporočila in pritisnite na \'Začni Prenos\'.',
	'PHPSHOP_WAITING_LIST_MESSAGE' => 'Vnesite svoj email naslov spodaj, da boste obveščeni ko bo izdelek spet na voljo v zalogi. 
		Vašega email naslova ne bomo posodili, prodali ali delili z nikomer koli, uporabili ga bomo izključno za obveščanje zalog izdelka.<br /><br />Najlepša Hvala!',
	'PHPSHOP_WAITING_LIST_THANKS' => 'Hvala za potrpežljivost! <br />Obvestili vas bomo tako ko bomo dobili naš inventar.',
	'PHPSHOP_WAITING_LIST_NOTIFY_ME' => 'Obvesti Me!',
	'PHPSHOP_SEARCH_ALL_CATEGORIES' => 'Išči po vseh kategorijah',
	'PHPSHOP_SEARCH_ALL_PRODINFO' => 'Išči po vseh informacijah o izdelkih',
	'PHPSHOP_SEARCH_PRODNAME' => 'Samo ime izdelka',
	'PHPSHOP_SEARCH_MANU_VENDOR' => 'Samo Proizvajalec/Prodajalec',
	'PHPSHOP_SEARCH_DESCRIPTION' => 'Samo opis Izdelka',
	'PHPSHOP_SEARCH_AND' => 'in',
	'PHPSHOP_SEARCH_NOT' => 'ne',
	'PHPSHOP_SEARCH_TEXT1' => 'Prvi spustn seznam vam dovoli izbiro kategorije za omejitev vašega iskanja. 
        Drugi spustni seznam vam dovoli omejitev vašega iskanja z uporabo določenega dela informacije o izdelku. (npr. Ime). 
        Ko ste izbrali te (ali pustili vse privzeto), vnesite ključno besedo za iskanje. ',
	'PHPSHOP_SEARCH_TEXT2' => ' Nadaljnje lahko omejite iskanje z uporabo druge ključne besede in z uporabo IN in NE operatorja.
        Uporaba IN pomeni, da morata biti obe besedi prisotni za izdelek, ki se bo prikazal. 
        Uporaba NE pomeni, da se bo izdelek prikazal samo če bo prisotna prva ključna beseda.',
	'PHPSHOP_CONTINUE_SHOPPING' => 'Nadaljuj nakupovanje',
	'PHPSHOP_AVAILABLE_IMAGES' => 'Uporabne Slike za',
	'PHPSHOP_BACK_TO_DETAILS' => 'Nazaj na podrobnosti izdelka',
	'PHPSHOP_IMAGE_NOT_FOUND' => 'Slike ni mogoče najti!',
	'PHPSHOP_PARAMETER_SEARCH_TEXT1' => 'Želite najti izdelke glede na tehnične parametre?<BR>Lahko uporabite katerikoli pripravljen obrazec:',
	'PHPSHOP_PARAMETER_SEARCH_NO_PRODUCT_TYPE' => 'Oprostite. Kategorija za iskanje ne obstaja.',
	'PHPSHOP_PARAMETER_SEARCH_BAD_PRODUCT_TYPE' => 'Oprostite. S tem imenom ni objavljen nobeden Tip Izdelka.',
	'PHPSHOP_PARAMETER_SEARCH_IS_LIKE' => 'Je kot',
	'PHPSHOP_PARAMETER_SEARCH_IS_NOT_LIKE' => 'ni kot',
	'PHPSHOP_PARAMETER_SEARCH_FULLTEXT' => 'Iskanje s polnim besedilom',
	'PHPSHOP_PARAMETER_SEARCH_FIND_IN_SET_ALL' => 'Vse izbrano',
	'PHPSHOP_PARAMETER_SEARCH_FIND_IN_SET_ANY' => 'Nekateri izbrani',
	'PHPSHOP_PARAMETER_SEARCH_RESET_FORM' => 'Počisti obrazec',	
	'PHPSHOP_PRODUCT_NOT_FOUND' => 'Oprostite ampak izdelka, ki ste ga zahtevali ni mogoče najti!',
	'PHPSHOP_PRODUCT_PACKAGING1' => 'Število {unit} v paketu:',
	'PHPSHOP_PRODUCT_PACKAGING2' => 'Število {unit}s v škatli:',
	'PHPSHOP_CART_PRICE_PER_UNIT' => 'Cena izdelka',
	'VM_PRODUCT_ENQUIRY_LBL' => 'Povprašajte o tem izdelku',
	'VM_RECOMMEND_FORM_LBL' => 'Priporočite izdelek prijatelju',
	'PHPSHOP_EMPTY_YOUR_CART' => 'Izprazni Košarico',
	'VM_RETURN_TO_PRODUCT' => 'Vrni se na izdelek',
	'EMPTY_CATEGORY' => 'Ta kategorija je trenutno prazna.',
	'ENQUIRY' => 'Povpraševanje',
	'NAME_PROMPT' => 'Vnesite vaše Ime',
	'EMAIL_PROMPT' => 'E-mail Naslov',
	'MESSAGE_PROMPT' => 'Vnesite vaše Sporočilo',
	'SEND_BUTTON' => 'Pošlji',
	'THANK_MESSAGE' => 'Hvala za vaše povpraševanje. Kontaktirali vas bomo takoj ko bo možno.',
	'PROMPT_CLOSE' => 'Zapri',
	'VM_RECOVER_CART_REPLACE' => 'Zamenjaj košarico s shranjeno Košarico',
	'VM_RECOVER_CART_MERGE' => 'Dodaj shranjeno košarico v trenutno košarico',
	'VM_RECOVER_CART_DELETE' => 'Izbriši Shranjeno Košarico',
	'VM_EMPTY_YOUR_CART_TIP' => 'Izprazni vsebino košarice',
	'VM_SAVED_CART_TITLE' => 'Shranjena Košarica',
	'VM_SAVED_CART_RETURN' => 'Vrni'
); $VM_LANG->initModule( 'shop', $langvars );
?>