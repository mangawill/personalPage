<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_ADMIN_CFG_PRICES_INCLUDE_TAX' => 'Prikazane Cene vsebujejo davek?',
	'PHPSHOP_ADMIN_CFG_PRICES_INCLUDE_TAX_EXPLAIN' => 'Nastavi zastavico, ki določa ali kupec vidi ceno z davkom ali brez njega.',
	'PHPSHOP_SHOPPER_FORM_ADDRESS_LABEL' => 'Vzdevek Naslova',
	'PHPSHOP_SHOPPER_GROUP_LIST_LBL' => 'Seznam skupine kupcev',
	'PHPSHOP_SHOPPER_GROUP_LIST_NAME' => 'Ime Skupine',
	'PHPSHOP_SHOPPER_GROUP_LIST_DESCRIPTION' => 'Opis Skupine',
	'PHPSHOP_SHOPPER_GROUP_FORM_LBL' => 'Obrazwc skupine kupcev',
	'PHPSHOP_SHOPPER_GROUP_FORM_NAME' => 'Ime Skupine',
	'PHPSHOP_SHOPPER_GROUP_FORM_DESC' => 'Opis Skupine',
	'PHPSHOP_SHOPPER_GROUP_FORM_DISCOUNT' => 'Popust na privzeto Skupino Kupcev (v %)',
	'PHPSHOP_SHOPPER_GROUP_FORM_DISCOUNT_TIP' => 'Pozitivna vrednost pomeni: Če izdelek nima nobene cene za TO Skupino Kupcev, se privzeta Cena zmanjša za X %. Negativna vrednost ima obraten učinek.'
); $VM_LANG->initModule( 'shopper', $langvars );
?>