<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_CARRIER_LIST_LBL' => 'Seznam Pošiljateljev',
	'PHPSHOP_RATE_LIST_LBL' => 'Seznam cen pošiljanje',
	'PHPSHOP_CARRIER_LIST_NAME_LBL' => 'Ime',
	'PHPSHOP_CARRIER_LIST_ORDER_LBL' => 'Vrstni red seznama',
	'PHPSHOP_CARRIER_FORM_LBL' => 'Uredi/Ustvari pošiljatelja',
	'PHPSHOP_RATE_FORM_LBL' => 'Ustvari/Uredi ceno Pošiljanja',
	'PHPSHOP_RATE_FORM_NAME' => 'Opis Cene Pošiljanja',
	'PHPSHOP_RATE_FORM_CARRIER' => 'Pošiljatelj',
	'PHPSHOP_RATE_FORM_COUNTRY' => 'Država',
	'PHPSHOP_RATE_FORM_ZIP_START' => 'Začetni ZIP niz',
	'PHPSHOP_RATE_FORM_ZIP_END' => 'Končni ZIP niz',
	'PHPSHOP_RATE_FORM_WEIGHT_START' => 'Najnižja teža',
	'PHPSHOP_RATE_FORM_WEIGHT_END' => 'Najvišja teža',
	'PHPSHOP_RATE_FORM_PACKAGE_FEE' => 'Vaša cena pakiranja',
	'PHPSHOP_RATE_FORM_CURRENCY' => 'Valuta',
	'PHPSHOP_RATE_FORM_LIST_ORDER' => 'Seznam Naročil',
	'PHPSHOP_SHIPPING_RATE_LIST_CARRIER_LBL' => 'Pošiljatelj',
	'PHPSHOP_SHIPPING_RATE_LIST_RATE_NAME' => 'Opis cene pošiljanja',
	'PHPSHOP_SHIPPING_RATE_LIST_RATE_WSTART' => 'Teža od ...',
	'PHPSHOP_SHIPPING_RATE_LIST_RATE_WEND' => '... do',
	'PHPSHOP_CARRIER_FORM_NAME' => 'Podjetje Pošiljatelja',
	'PHPSHOP_CARRIER_FORM_LIST_ORDER' => 'Vrstni red seznama'
); $VM_LANG->initModule( 'shipping', $langvars );
?>