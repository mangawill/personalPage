<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 
/**
*
* @version $Id: slovenian.php 1071 2010-10-07 08:42:28Z thepisu $
* @package VirtueMart
* @subpackage languages
* @copyright Copyright (C) 2010-2011 Jure Štern - All rights reserved.
* @translator Jure Štern http://jure-stern.si
* @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
* VirtueMart is free software. This version may have been modified pursuant
* to the GNU General Public License, and as distributed it includes or
* is derivative of works licensed under the GNU General Public License or
* other free or open source software licenses.
* See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.
*
* http://virtuemart.net
*/
global $VM_LANG;
$langvars = array (
	'CHARSET' => 'UTF-8',
	'PHPSHOP_ORDER_PRINT_PAYMENT_LOG_LBL' => 'Dnevnik Plačil',
	'PHPSHOP_ORDER_PRINT_SHIPPING_PRICE_LBL' => 'Cena Pošiljke',
	'PHPSHOP_ORDER_STATUS_LIST_CODE' => 'Koda Statusa Naročila',
	'PHPSHOP_ORDER_STATUS_LIST_NAME' => 'Ime Statusa Naročila',
	'PHPSHOP_ORDER_STATUS_FORM_LBL' => 'Status Naročila',
	'PHPSHOP_ORDER_STATUS_FORM_CODE' => 'Koda Statusa Naročila',
	'PHPSHOP_ORDER_STATUS_FORM_NAME' => 'Ime Statusa Naročila',
	'PHPSHOP_ORDER_STATUS_FORM_LIST_ORDER' => 'Seznam Naročil',
	'PHPSHOP_COMMENT' => 'Komentar',
	'PHPSHOP_ORDER_LIST_NOTIFY' => 'Obvesti Kupca?',
	'PHPSHOP_ORDER_LIST_NOTIFY_ERR' => 'Prosimo, da prej spremenite status naročila!',
	'PHPSHOP_ORDER_HISTORY_INCLUDE_COMMENT' => 'Vključi ta komentar?',
	'PHPSHOP_ORDER_HISTORY_DATE_ADDED' => 'Datum Dodajanja',
	'PHPSHOP_ORDER_HISTORY_CUSTOMER_NOTIFIED' => 'Stranka Obveščena?',
	'PHPSHOP_ORDER_STATUS_CHANGE' => 'Sprememba Statusa Naročila',
	'PHPSHOP_ORDER_LIST_PRINT_LABEL' => 'Natisni Etiketo',
	'PHPSHOP_ORDER_LIST_VOID_LABEL' => 'Prazna Etiketa',
	'PHPSHOP_ORDER_LIST_TRACK' => 'Sledi',
	'VM_DOWNLOAD_STATS' => 'PRENESI STATUS',
	'VM_DOWNLOAD_NOTHING_LEFT' => 'ni več prenosov',
	'VM_DOWNLOAD_REENABLE' => 'Zopet Usposobi Prenos',
	'VM_DOWNLOAD_REMAINING_DOWNLOADS' => 'Preostali Prenosi',
	'VM_DOWNLOAD_RESEND_ID' => 'Ponovno pošlji ID prenosa',
	'VM_EXPIRY' => 'Potek',
	'VM_UPDATE_STATUS' => 'Posodobi Status',
	'VM_ORDER_LABEL_ORDERID_NOTVALID' => 'Prosim preskrbite veljaven, številčen, ID naročila, ne pa "{order_id}"',
	'VM_ORDER_LABEL_NOTFOUND' => 'Naročitvene vrstice ni mogoče najti v bazi pošiljanja.',
	'VM_ORDER_LABEL_NEVERGENERATED' => 'Etiketa še ni bila generirana',
	'VM_ORDER_LABEL_CLASSCANNOT' => 'Stil {ship_class} ne more dobiti slik etikete, zakaj smo tukaj?',
	'VM_ORDER_LABEL_SHIPPINGLABEL_LBL' => 'Etiketa Pošiljanja',
	'VM_ORDER_LABEL_SIGNATURENEVER' => 'Podpis ni bil nikoli obnovljen',
	'VM_ORDER_LABEL_TRACK_TITLE' => 'Sledi',
	'VM_ORDER_LABEL_VOID_TITLE' => 'Prazna Etiketa',
	'VM_ORDER_LABEL_VOIDED_MSG' => 'Etiketa za waybill {tracking_number} je bila izpraznjena.',
	'VM_ORDER_PRINT_PO_IPADDRESS' => 'IP-NASLOV',
	'VM_ORDER_STATUS_ICON_ALT' => 'Status Ikona',
	'VM_ORDER_PAYMENT_CCV_CODE' => 'CVV Koda',
	'VM_ORDER_NOTFOUND' => 'Naročila ni bilo mogoče najti! Lahko je bilo že izbrisano.',
	'PHPSHOP_ORDER_EDIT_ACTIONS' => 'Akcije',
	'PHPSHOP_ORDER_EDIT' => 'Spremenite Podrobnosti Naročila',
	'PHPSHOP_ORDER_EDIT_ADD' => 'Dodaj',
	'PHPSHOP_ORDER_EDIT_ADD_PRODUCT' => 'Dodaj Izdelek',
	'PHPSHOP_ORDER_EDIT_EDIT_ORDER' => 'Spremeni Naročilo',
	'PHPSHOP_ORDER_EDIT_ERROR_QUANTITY_MUST_BE_HIGHER_THAN_0' => 'Količina mora biti večja od 0.',
	'PHPSHOP_ORDER_EDIT_PRODUCT_ADDED' => 'Izdelek je bil dodan v naročilo',
	'PHPSHOP_ORDER_EDIT_PRODUCT_DELETED' => 'Izdelek je bil odstranjen iz naročila',
	'PHPSHOP_ORDER_EDIT_QUANTITY_UPDATED' => 'Količina je bila posodobljena',
	'PHPSHOP_ORDER_EDIT_RETURN_PARENTS' => 'nazaj na Glavni Izdelek',
	'PHPSHOP_ORDER_EDIT_CHOOSE_PRODUCT' => 'Izberite Izdelek',
	'PHPSHOP_ORDER_CHANGE_UPD_BILL' => 'Spremenite naslov računa',
	'PHPSHOP_ORDER_CHANGE_UPD_SHIP' => 'Spremenite naslov pošiljanja',
	'PHPSHOP_ORDER_EDIT_SOMETHING_HAS_CHANGED' => ' je bil spremenjen',
	'PHPSHOP_ORDER_EDIT_CHOOSE_PRODUCT_BY_SKU' => 'Izberite Kataloško številko'
); $VM_LANG->initModule( 'order', $langvars );
?>
